public class Main {

    public static void main(String[] args) {
	 Teacher object = new Teacher();
	  System.out.println("Name of Teacher:" + object.Name);
    }
}
