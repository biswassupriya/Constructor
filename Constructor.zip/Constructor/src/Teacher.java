public class Teacher {
    private String Name;
    private int Experience;
    private String Teacher;
    {
        public Teacher(){
             Name = "NoName";
             Experience = 1;
             Teacher = "Null";


    }
    }
}
